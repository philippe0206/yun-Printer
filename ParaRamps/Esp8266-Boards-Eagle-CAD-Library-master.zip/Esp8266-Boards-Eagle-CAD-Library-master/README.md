# Esp8266 Boards Eagle CAD Library
Esp-8266 Boards for Eagle CAD.
->I never found an Appropriate Designs for esp8266 boards Excluding Esp-12 and Esp-01 from internet.
Therefore i started making my own library for Esp8266 Boards.
I have started with Esp-02 PCB as there was no design on internet for this board.
I also need an Financial back support from people to help me complete this library with all designs off esp8266 Boards.
Therefore you can donate as low as $7 to this repo to get a Specific Design which would be added to library for public use.
The Modules which my supplier has are: ( Almost All)

1) ESP-01 (✓ PCB Added)

2) ESP-02 (✓ PCB Added)

3) ESP-03 (✓ PCB Added)

4) ESP-04

5) ESP-05

6) ESP-07

7) ESP-08

8) ESP-09

9) ESP-10

10) ESP-11

11) ESP-12 & ESP-12E

12) ESP-13 

13) ESP-WPROOM2

I Hope Everybody support me & Expand the IoT Population :)

# Donate

Donate 7$ Min. to "hobbyists.stop@gmail.com" Through Paypal.


# How to Install 

1)To Install this Liibrary first Download the Zip from right -->

2) Then Extract the Zip 

3) Now, Move the "ESP-8266 Boards" Folder to "/lbr" lbr folde in your eagle directory .

4) Done, Now open Eagle and Drop Down the "Libraries" List.

You will find the Esp-8266 Library there.

# License

This Library is Issued under GPL ( General Public License ) 

